	<footer id="pageBottom">
	<a href="/index" class="bottom_links">Home</a>
	<a href="/login" class="bottom_links">Log In</a>
	<a href="/signup" class="bottom_links">Sign Up</a>
	<a href="/help" class="bottom_links">Help &amp; Support</a>
	<a href="/policies" class="bottom_links">Privacy and Policy</a>
	<a href="/jedit" class="bottom_links">JEdit</a>
	<a href="/wordic" class="bottom_links">Wordic</a>
	<a href="/games/inferno" class="bottom_links">Survive Inferno</a>
	<a href="/forgot_password" class="bottom_links">Forgotten Password</a>
	<a href="/stockai" class="bottom_links">Stock AI</a>
	<hr class="dimw">
	<br />
	&copy; <?php echo date("Y"); ?> Pearscom<br><br>
</footer>